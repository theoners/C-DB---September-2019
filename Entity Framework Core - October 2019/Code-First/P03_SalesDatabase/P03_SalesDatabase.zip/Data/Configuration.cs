﻿namespace P03_SalesDatabase.Data
{
     static class Configuration
     {
         internal const string ConnectionString = @"Server = ASUS\SQLEXPRESS;Database = SalesDatabase;Integrated Security = true;";
     }
}
